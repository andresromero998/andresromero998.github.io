# Andrés Romero — Portfolio

Sitio personal en una sola página (HTML). Secciones: **Studies**, **Research**, **Work Experience** y **Contact**.

## Cómo usar (rápido)
1) **Descarga este proyecto** como ZIP y descomprímelo.
2) Abre `index.html` con doble clic para verlo en tu navegador.
3) Para editar, abre `index.html` con VS Code o el bloc de notas.

## Qué cambiar en `index.html`
- **Email:** busca `andres.romero@example.com` y reemplázalo por el tuyo.
- **LinkedIn:** busca `https://www.linkedin.com/` y pega tu URL real.
- **CV:** coloca tu PDF en `cv/AndresRomero_CV.pdf` (o cambia la ruta del enlace).
- **Foto:** reemplaza `img/andres.jpg` por tu foto usando ese mismo nombre (o cambia la ruta en el HTML).

## Estructura de carpetas
```
andres-portfolio-starter/
├─ index.html
├─ README.md
├─ img/
│  └─ andres.jpg   (pon aquí tu foto con ese nombre)
└─ cv/
   └─ AndresRomero_CV.pdf   (pon aquí tu CV en PDF)
```

## Publicar gratis con GitHub Pages
1. Crea un repositorio nuevo en GitHub (por ejemplo `portfolio`).
2. Sube **todos** los archivos y carpetas de este proyecto.
3. Ve a **Settings → Pages**.
4. En **Branch**, selecciona `main` y `/ (root)` → **Save**.
5. Tu sitio quedará en `https://TU_USUARIO.github.io/portfolio/`.

> Consejo: si cambias nombres de carpetas o archivos, recuerda actualizar sus rutas en `index.html`.
